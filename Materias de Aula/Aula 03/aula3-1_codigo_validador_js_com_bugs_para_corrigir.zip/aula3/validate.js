// (namespace)
const fatecValidator = (function createFatecValidator() {

    const TOGGLE_ATTRIBUTE_NAME = `fatec-validate-toggle`;
    const CHAR_REGEX_ATTRIBUTE_NAME = `fatec-validate-char-regex`;
    const REQUIRED_ATTRIBUTE_NAME = `fatec-validate-required`;
    const MIN_LENGTH_ATTRIBUTE_NAME = `fatec-validate-min`;
    const IDENTIFIER = `fatec-identifier`;

    let toggles;
    let requiredFields;
    let fieldsWithMinSize;
    let fieldsWhoseCharsAcceptOnlyRegex;
    let pageRequiresValidation;
    let validationActivated;
    const errorByField = {};
    const generateUniqueIdentifier = createSequence();

    (function lookForValidationTagsInHTML() {
        console.debug(`Looking for fatec-validate attributes...`);
        toggles = document.querySelectorAll(`[${TOGGLE_ATTRIBUTE_NAME}]`);
        requiredFields = document.querySelectorAll(`[${REQUIRED_ATTRIBUTE_NAME}]`);
        fieldsWithMinSize = document.querySelectorAll(`[${MIN_LENGTH_ATTRIBUTE_NAME}]`);
        fieldsWhoseCharsAcceptOnlyRegex = document.querySelectorAll(`[${CHAR_REGEX_ATTRIBUTE_NAME}]`);

        console.debug(`Found ${toggles.length} toggles`);
        console.debug(`Found ${requiredFields.length} required fields`);
        console.debug(`Found ${fieldsWithMinSize.length} fields with min size restriction`);
        console.debug(`Found ${fieldsWhoseCharsAcceptOnlyRegex.length} fields whose chars accept only a specific regex`);

        pageRequiresValidation = (requiredFields.length > 0 || fieldsWithMinSize.length > 0 || fieldsWhoseCharsAcceptOnlyRegex.length > 0);
        console.debug(`Does the page require validation? ${pageRequiresValidation}`);
    })();

    if (pageRequiresValidation) {

        configureToggles();
        registerChangeEventsToFields();

    } else {
        console.debug(`As the pages doesn't require validation, exit!`);
    }

    function configureToggles() {
        console.debug(`Configuring toggles...`);
        if (0 === toggles.length) {
            console.debug(`There are no toggles. Assuming validating activated`);
            activateValidation();
        } else {
            if (!areAllTogglesInSameState()) {
                console.error(`At least one toggle is in a different state. It shouldn't happen. Fix that before continuing!`);
                return;
            }

            console.debug(`Ready to configure toggles`);
            toggles.forEach(function forEachToggle(toggle) {
                toggle.addEventListener("change", function toggleChanged() {
                    updateValidationStateBasedOnToggle(toggle);
                    propagateStateChangeToOtherToggles(toggle.checked);
                });
            });

            updateValidationStateBasedOnToggle(toggles[0]);
        }
    }

    function areAllTogglesInSameState() {
        console.debug(`Checking whether all toggles are in the same state`);
        const howManyCheckedToggles = document.querySelectorAll(`[${TOGGLE_ATTRIBUTE_NAME}]:checked`).length;
        console.debug(`Found ${howManyCheckedToggles} checked toggles`);
        console.debug(`Comparing with ${toggles.length} total toggles`);
        const result = 0 === howManyCheckedToggles || howManyCheckedToggles === toggles.length;
        console.debug(result ? `Yes, they are` : `No, they aren't`);
        return result;
    }

    function propagateStateChangeToOtherToggles(newState) {
        console.debug(`Propagating the new state (${newState}) to all toggles...`);
        toggles.forEach(function propagateStateChangeToToggle(toggle) {
            toggle.checked = newState;
        });
    }

    function updateValidationStateBasedOnToggle(toggle) {
        console.debug(`Checking whether the toggle ${toggle} is checked`);
        if (toggle.checked) {
            console.debug(`Yes, it is. Activating validation...`);
            activateValidation();
        } else {
            console.debug(`No, it isn't. Deactivating validation...`);
            deactivateValidation();
        }
    }

    function activateValidation() {
        validationActivated = true;
    }

    function deactivateValidation() {
        validationActivated = false;
    }

    function isValidationActivated() {
        return validationActivated;
    }

    function registerChangeEventsToFields() {
        console.debug(`Registering change events to fields`);
        const fieldSet = new Set();
        requiredFields.forEach(field => fieldSet.add(field));
        fieldsWithMinSize.forEach(field => fieldSet.add(field));
        fieldsWhoseCharsAcceptOnlyRegex.forEach(field => fieldSet.add(field));
        console.debug(`Fields: `, fieldSet);

        fieldSet.forEach(function forEachField(field) {
            field.setAttribute(IDENTIFIER, generateUniqueIdentifier());
            if (hasToHaveCharValidatedByRegex(field))
                field.addEventListener("keypress", keyPressedOnField);
            field.addEventListener("keyup", keyUpOnField);
        })
    }

    function keyPressedOnField(event) {
        const field = event.target;
        console.debug(`A key was pressed on ${field}`);
        if (!isValidationActivated()) {
            console.debug(`Ignoring: the validation is deactivated`);
            return;
        }

        if (hasToHaveCharValidatedByRegex(field)) {
            const charValidationRegex = new RegExp(`${getFieldCharValidationRegex(field)}`);
            if (!charValidationRegex.test(event.key)) {
                console.debug(`Ignoring: invalid char`);
                event.preventDefault();
            }
        }
    }

    function keyUpOnField(event) {
        const field = event.target;
        const fieldLength = field.value.length;
        console.debug(`A key is up on ${field}`);
        if (!isValidationActivated()) {
            console.debug(`Ignoring: the validation is deactivated`);
            return;
        }

        console.debug(`The current field length is ${fieldLength}`);

        if (hasToBeValidatedRegardingMinLength(field)) {
            errorByField[getFieldIdentifier(field)] = {
                field: event.target,
                errorMessage: fieldLength < getFieldMinLength(field) ? `O campo deve ter, no mínimo, tamanho ${getFieldMinLength(field)}` : undefined
            };
        } else if (isRequired(field)) {
            errorByField[getFieldIdentifier(field)] = {
                field,
                errorMessage: 0 === fieldLength ? `O campo é obrigatório` : undefined
            };;
        }

        updateUI();
    }

    function getFieldIdentifier(field) {
        return field.getAttribute(IDENTIFIER);
    }

    function hasToHaveCharValidatedByRegex(field) {
        return field.hasAttribute(CHAR_REGEX_ATTRIBUTE_NAME);
    }

    function getFieldCharValidationRegex(field) {
        return field.getAttribute(CHAR_REGEX_ATTRIBUTE_NAME);
    }

    function isRequired(field) {
        return field.hasAttribute(REQUIRED_ATTRIBUTE_NAME);
    }

    function hasToBeValidatedRegardingMinLength(field) {
        return field.hasAttribute(MIN_LENGTH_ATTRIBUTE_NAME);
    }

    function getFieldMinLength(field) {
        return parseInt(field.getAttribute(MIN_LENGTH_ATTRIBUTE_NAME));
    }

    function updateUI() {
        console.debug(`Updating UI...`);
        if (isValidationActivated()) {
            for (const fieldIdentifier in errorByField) {
                if (errorByField[fieldIdentifier].errorMessage) {
                    const field = errorByField[fieldIdentifier].field;
                    const errorMessageContainer = getErrorMessageContainerForField(field);
                    errorMessageContainer.innerText = errorByField[fieldIdentifier].errorMessage;
                } else {
                    hideValidationForField(errorByField[fieldIdentifier].field);
                }
            }
        } else {
            hideValidationUI();
        }
    }

    function getErrorMessageContainerForField(field) {
        let errorMessageContainer = field.parentNode.querySelector('.js-fatec-error-message');
        if (errorMessageContainer) {
            errorMessageContainer.classList.remove('escondido');
            return errorMessageContainer;
        }

        errorMessageContainer = document.createElement('div');
        errorMessageContainer.classList.add('erro', 'js-fatec-error-message');
        field.parentNode.insertBefore(errorMessageContainer, field.nextSibling);
        return errorMessageContainer;
    }

    function hideValidationUI() {
        document.querySelectorAll('.js-fatec-error-message').forEach(function forEachErrorMessageContainer(errorMessageContainer) {
            console.log(errorMessageContainer);
            errorMessageContainer.classList.add('escondido');
        });
    }

    function hideValidationForField(field) {
        field.parentNode.querySelector('.js-fatec-error-message')?.classList.add('escondido');
    }

    function createSequence() {
        let current = 1;
        return function next() {
            return current++;
        }
    }

})();