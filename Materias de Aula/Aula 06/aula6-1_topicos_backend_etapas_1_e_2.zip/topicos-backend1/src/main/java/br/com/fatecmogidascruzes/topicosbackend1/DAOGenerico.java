package br.com.fatecmogidascruzes.topicosbackend1;

import br.com.fatecmogidascruzes.topicosbackend1.persistencia.BancoDados;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOGenerico {

    // Hipoteses iniciais (depois serao removidas):
    // 1 - Para cada classe, existe uma tabela com o mesmo nome da classe, so que minusculo e precedido por _
    // 2 - Para cada atributo, existe uma coluna com o mesmo nome do atributo, so que minusculo
    // 3 - Todos os atributos sao persistentes
    // 4 - A chave da classe no banco tem o nome id e diz respeito ao atributo id (gerado automaticamente)

    public void salvar(Object objeto) throws ClassNotFoundException, SQLException, IllegalAccessException {

        String sql = "INSERT INTO ";
        sql += "_" + objeto.getClass().getSimpleName().toLowerCase();
        sql += "(";

        String fimSQL = " VALUES(";

        Field[] atributos = objeto.getClass().getDeclaredFields();
        for(Field atributo : atributos) {
            if(!atributo.getName().equalsIgnoreCase("id")) {
                sql += atributo.getName().toLowerCase() + ", ";
                fimSQL += "?, ";
            }
        }
        sql = sql.substring(0, sql.length() - 2);
        sql += ")";

        fimSQL = fimSQL.substring(0, fimSQL.length() - 2);
        fimSQL += ")";

        sql += fimSQL;

        try (Connection conexao = BancoDados.getConexao()) {
            int numeroInterrogacao = 1;
            PreparedStatement sqlPreparado = conexao.prepareStatement(sql);
            for(Field atributo : atributos) {
                if(!atributo.getName().equalsIgnoreCase("id")) {
                    atributo.setAccessible(true);
                    Object valorAtributo = atributo.get(objeto);
                    sqlPreparado.setObject(numeroInterrogacao++, valorAtributo);
                }
            }
            sqlPreparado.executeUpdate();
        }

    }

}
