package br.com.fatecmogidascruzes.topicosbackend1;

import java.time.LocalDate;

public class Compromisso {

    private int id;
    private LocalDate data;
    private String descricao;
    private boolean confirmado;

    public Compromisso(LocalDate data, String descricao, boolean confirmado) {
        this.data = data;
        this.descricao = descricao;
        this.confirmado = confirmado;
    }
}
