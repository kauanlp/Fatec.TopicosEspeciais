package br.com.fatecmogidascruzes.topicosbackend1;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GestaoContato extends HttpServlet {

    public void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        String acao = request.getParameter("acao");

        if (acao == null) {
            try {
                Connection conexao = getConexao();

                PreparedStatement sql = conexao.prepareStatement("SELECT id, nome, telefone, email FROM _contatos");
                ResultSet resultado = sql.executeQuery();
                List<Contato> contatos = new ArrayList<>();
                while (resultado.next()) {
                    Contato contato = new Contato(resultado.getInt("id"),
                            resultado.getString("nome"),
                            resultado.getString("telefone"),
                            resultado.getString("email"));
                    contatos.add(contato);
                }

                request.setAttribute("contatos", contatos);
                conexao.close();
                request.getRequestDispatcher("/index.jsp").forward(request, response);
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else if (acao.equalsIgnoreCase("inserir")) {
            try {
                String nome = request.getParameter("nome");
                Connection conexao = getConexao();

                PreparedStatement sql = conexao.prepareStatement("INSERT INTO _contatos(nome, telefone, email) VALUES(?, ?, ?)");
                sql.setString(1, nome);
                sql.setString(2, request.getParameter("telefone"));
                sql.setString(3, request.getParameter("email"));
                sql.executeUpdate();
                conexao.close();

                request.getRequestDispatcher("/sucessoInsercao.jsp").forward(request, response);
            } catch (SQLException | ClassNotFoundException e) {
                request.setAttribute("mensagem", e.getMessage());
                request.getRequestDispatcher("/falhaInsercao.jsp").forward(request, response);
            }
        } else if (request.getParameter("alterar") != null) {
            try {
                String idStr = request.getParameter("alterar");
                int id = Integer.valueOf(idStr);

                Connection conexao = getConexao();
                PreparedStatement sql = conexao.prepareStatement("SELECT id, nome, telefone, email FROM _contatos WHERE id=?");
                sql.setInt(1, id);

                Contato contato = null;
                ResultSet resultado = sql.executeQuery();
                if (resultado.next()) {
                    contato = new Contato(resultado.getInt("id"), resultado.getString("nome"), resultado.getString("telefone"), resultado.getString("email"));
                }
                conexao.close();
                request.setAttribute("contato", contato);
                request.getRequestDispatcher("/alterar.jsp").forward(request, response);
            } catch (SQLException | ClassNotFoundException e) {
                request.setAttribute("mensagem", e.getMessage());
                request.getRequestDispatcher("/alterar.jsp").forward(request, response);
            }
        } else if (acao.equalsIgnoreCase("atualizar")) {
            try {
                String idStr = request.getParameter("id");
                int id = Integer.valueOf(idStr);

                Connection conexao = getConexao();

                PreparedStatement sql = conexao.prepareStatement("UPDATE _contatos SET nome=?, telefone=?, email=? WHERE id=?");
                sql.setString(1, request.getParameter("nome"));
                sql.setString(2, request.getParameter("telefone"));
                sql.setString(3, request.getParameter("email"));
                sql.setInt(4, id);
                sql.executeUpdate();
                conexao.close();

                request.getRequestDispatcher("/sucessoAtualizacao.jsp").forward(request, response);
            } catch (SQLException | ClassNotFoundException e) {
                request.setAttribute("mensagem", e.getMessage());
                request.getRequestDispatcher("/falhaAtualizacao.jsp").forward(request, response);
            }
        } else if (request.getParameter("excluir") != null) {
            try {
                String idStr = request.getParameter("excluir");
                int id = Integer.valueOf(idStr);

                Connection conexao = getConexao();
                PreparedStatement sql = conexao.prepareStatement("SELECT id, nome, telefone, email FROM _contatos WHERE id=?");
                sql.setInt(1, id);

                Contato contato = null;
                ResultSet resultado = sql.executeQuery();
                if (resultado.next()) {
                    contato = new Contato(resultado.getInt("id"), resultado.getString("nome"), resultado.getString("telefone"), resultado.getString("email"));
                }
                conexao.close();

                request.setAttribute("contato", contato);
                request.getRequestDispatcher("/confirmarExclusao.jsp").forward(request, response);
            } catch (SQLException | ClassNotFoundException e) {
                request.setAttribute("mensagem", e.getMessage());
                request.getRequestDispatcher("/confirmarExclusao.jsp").forward(request, response);
            }
        } else if (acao.equalsIgnoreCase("confirmarExclusao")) {
            try {
                String idStr = request.getParameter("id");
                int id = Integer.valueOf(idStr);

                Connection conexao = getConexao();

                PreparedStatement sql = conexao.prepareStatement("DELETE FROM _contatos WHERE id=?");
                sql.setInt(1, id);
                sql.executeUpdate();
                conexao.close();

                request.getRequestDispatcher("/sucessoExclusao.jsp").forward(request, response);
            } catch (SQLException | ClassNotFoundException e) {
                request.setAttribute("mensagem", e.getMessage());
                request.getRequestDispatcher("/falhaExclusao.jsp").forward(request, response);
            }
        }

    }

    private Connection getConexao() throws ClassNotFoundException, SQLException {
        Class.forName("org.postgresql.Driver");
        Connection conexao = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:5432/db", "user", "abc12345");
        return conexao;
    }

}