package br.com.fatecmogidascruzes.topicosbackend1;

import br.com.fatecmogidascruzes.topicosbackend1.persistencia.BancoDados;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Contato {

    private int id;
    private String nome;
    private String telefone;
    private String email;

    public Contato(int id) {
        this.id = id;
    }

    public Contato(String nome, String telefone, String email) {
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
    }

    public Contato(int id, String nome, String telefone, String email) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void salvar() throws ClassNotFoundException, SQLException {
        try (Connection conexao = BancoDados.getConexao()) {
            PreparedStatement sql = conexao.prepareStatement("INSERT INTO _contatos(nome, telefone, email) VALUES(?, ?, ?)");
            sql.setString(1, nome);
            sql.setString(2, telefone);
            sql.setString(3, email);
            sql.executeUpdate();
        }
    }

    public void atualizar() throws ClassNotFoundException, SQLException {
        try (Connection conexao = BancoDados.getConexao()) {
            PreparedStatement sql = conexao.prepareStatement("UPDATE _contatos SET nome=?, telefone=?, email=? WHERE id=?");
            sql.setString(1, nome);
            sql.setString(2, telefone);
            sql.setString(3, email);
            sql.setInt(4, id);
            sql.executeUpdate();
        }
    }

    public void excluir() throws ClassNotFoundException, SQLException {
        try (Connection conexao = BancoDados.getConexao()) {
            PreparedStatement sql = conexao.prepareStatement("DELETE FROM _contatos WHERE id=?");
            sql.setInt(1, id);
            sql.executeUpdate();
        }
    }

    public static List<Contato> listarTodos() throws ClassNotFoundException, SQLException {
        try (Connection conexao = BancoDados.getConexao()) {
            PreparedStatement sql = conexao.prepareStatement("SELECT id, nome, telefone, email FROM _contatos");
            ResultSet resultado = sql.executeQuery();
            List<Contato> contatos = new ArrayList<>();
            while (resultado.next()) {
                Contato contato = new Contato(resultado.getInt("id"),
                        resultado.getString("nome"),
                        resultado.getString("telefone"),
                        resultado.getString("email"));
                contatos.add(contato);
            }
            return contatos;
        }
    }

    public static Contato consultarPorId(int id) throws ClassNotFoundException, SQLException {
        try (Connection conexao = BancoDados.getConexao()) {
            PreparedStatement sql = conexao.prepareStatement("SELECT id, nome, telefone, email FROM _contatos WHERE id=?");
            sql.setInt(1, id);

            Contato contato = null;
            ResultSet resultado = sql.executeQuery();
            if (resultado.next()) {
                contato = new Contato(resultado.getInt("id"), resultado.getString("nome"), resultado.getString("telefone"), resultado.getString("email"));
            }
            return contato;
        }
    }

}
