const http = require('http');

const server = http.createServer(function servidorWeb(req, res) {
    res.writeHead(200);
    res.end(`O endereço da residência é Rua Carlos Barattino, Vila Nova Mogilar - Mogi das Cruzes/SP`);
});

server.listen(9001, function started() {
    console.log("O servidor está 'ouvindo' a porta 9001 em 127.0.0.1")
});