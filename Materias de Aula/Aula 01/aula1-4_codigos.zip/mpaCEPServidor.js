const http = require('http');

const server = http.createServer(function servidorWeb(req, res) {
    res.writeHead(200);
    res.end(`<!DOCTYPE html>
                <html>
                    <head>
                        <title>
                            Consulta de CEP
                        </title>
                        <meta charset="utf-8" />
                    </head>
                    <body>
                        <h1>Aplicação de CEP</h1>
                        <p>O endereço da residência é Rua Carlos Barattino, Vila Nova Mogilar - Mogi das Cruzes/SP</p>
                    </body>
                </html>`);
});

server.listen(9000, function started() {
    console.log("O servidor está 'ouvindo' a porta 9000 em 127.0.0.1")
});